SELECT booking_awarded_count.id,
       booking_awarded_count.property_name AS property_name,
       (booking_awarded_count.current / booking_count.current) AS current,
       (booking_awarded_count.historic / booking_count.historic) AS historic
  FROM (SELECT current_table.id,
               current_table.name AS property_name,
               current_table.value AS current,
               historic_table.value AS historic
          FROM (SELECT COUNT(DISTINCT b.id) AS value, p.name, p.id
                  FROM x_property p, x_booking b, x_upgrade_request ur
                 WHERE     b.property_id IN (87,856,694,1056,474,1301,455,1943,20,808,190,426,1888)
                       AND b.property_id = p.id
                       AND b.id = ur.booking_id
                       AND ur.awarded = 'yes'
                       AND b.arrival BETWEEN '2012-07-01' AND '2012-07-31'
                       AND b.arrival < CURDATE()
                GROUP BY b.property_id) current_table,
               (SELECT COUNT(DISTINCT b.id) AS value, p.name, p.id
                  FROM x_property p, x_booking b, x_upgrade_request ur
                 WHERE     b.property_id IN (87,856,694,1056,474,1301,455,1943,20,808,190,426,1888)
                       AND b.property_id = p.id
                       AND b.id = ur.booking_id
                       AND ur.awarded = 'yes'
                       AND b.arrival BETWEEN '2012-06-01' AND '2012-06-30'
                       AND b.ARRIVAL < CURDATE()
                GROUP BY b.property_id) historic_table
         WHERE current_table.id = historic_table.id) booking_awarded_count,
       (SELECT current_table.id,
               current_table.name AS property_name,
               current_table.value AS current,
               historic_table.value AS historic
          FROM (SELECT COUNT(DISTINCT b.id) AS value, p.name, p.id
                  FROM x_booking b, x_property p, x_upgrade_request ur
                 WHERE     b.property_id IN (87,856,694,1056,474,1301,455,1943,20,808,190,426,1888)
                       AND b.property_id = p.id
                       AND b.id = ur.booking_id
                       AND b.arrival BETWEEN '2012-07-01' AND '2012-07-31'
                       AND b.arrival < CURDATE()
                GROUP BY b.property_id) current_table,
               (SELECT COUNT(DISTINCT b.id) AS value, p.name, p.id
                  FROM x_booking b, x_property p, x_upgrade_request ur
                 WHERE     b.property_id IN (87,856,694,1056,474,1301,455,1943,20,808,190,426,1888)
                       AND b.property_id = p.id
                       AND b.id = ur.booking_id
                       AND b.arrival BETWEEN '2012-06-01' AND '2012-06-30'
                       AND b.ARRIVAL < CURDATE()
                GROUP BY b.property_id) historic_table
         WHERE current_table.id = historic_table.id) booking_count
 WHERE booking_awarded_count.id = booking_count.id
ORDER BY id