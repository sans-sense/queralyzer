SELECT current_table.id,
       current_table.name AS property_name,
       current_table.value AS current,
       historic_table.value AS historic
  FROM (SELECT SUM(ur.total) AS value, p.name, p.id
          FROM x_booking b, x_upgrade_request ur, x_property p
         WHERE b.property_id IN
                  (87,856,694,1056,474,1301,455,1943,20,808,190,426,1888) 
               AND b.id = ur.`booking_id`
               AND b.property_id = p.id
               AND ur.awarded = 'pending'
               AND b.arrival BETWEEN '2012-07-01' AND '2012-07-31'
               AND b.arrival < CURDATE()
        GROUP BY ur.property_id) current_table,
       (SELECT SUM(ur.total) AS value, p.name, p.id
          FROM x_booking b, x_upgrade_request ur, x_property p
         WHERE b.property_id IN
                  (87,856,694,1056,474,1301,455,1943,20,808,190,426,1888) 
               AND b.id = ur.`booking_id`
               AND b.property_id = p.id
               AND ur.awarded = 'pending'
               AND b.arrival BETWEEN '2012-06-01' AND '2012-06-30'
               AND b.arrival < CURDATE()
        GROUP BY ur.property_id) historic_table
 WHERE current_table.id = historic_table.id
ORDER BY id