SELECT current_table.id,
       current_table.name AS property_name,
       current_table.guests_exposed AS current,
       historic_table.guests_exposed AS historic
  FROM (SELECT COUNT(e.gad) AS guests_exposed, p.id, p.name
          FROM x_property p, exposure e
         WHERE     p.id IN (87,856,694,1056,474,1301,455,1943,20,808,190,426,1888)
               AND e.gad BETWEEN '2012-07-01' AND '2012-07-31'
               AND e.gad < CURDATE()
               AND e.property_id = p.id
        GROUP BY e.property_id) current_table,
       (SELECT COUNT(1) AS guests_exposed, p.id, p.name
          FROM x_property p, exposure e
         WHERE     p.id IN (87,856,694,1056,474,1301,455,1943,20,808,190,426,1888)
               AND e.gad BETWEEN '2012-06-01' AND '2012-06-30'
               AND e.gad < CURDATE()
               AND e.property_id = p.id
        GROUP BY e.property_id) historic_table
 WHERE current_table.id = historic_table.id
ORDER BY id